from usermanage.run import allruns
allruns()